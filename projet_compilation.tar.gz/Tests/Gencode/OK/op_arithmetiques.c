void main(){

	int a=1;
	int b=-1;
	
	a=a+b;
	a=a*b;
	a=a/b;
	a=a%b;
	a=b-a;
	a=-a;
	
	a=a+1;
	a=a*1;
	a=a/1;
	a=a%1;
	a=a-1;
	
	a=1+a;
	a=1*a;
	a=1/a;
	a=1%a;
	a=1-a;
	
	a=1+1;
	a=1*1;
	a=1/1;
	a=1%1;
	a=-1;
}
