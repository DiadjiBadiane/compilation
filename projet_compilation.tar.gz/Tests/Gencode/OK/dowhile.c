void main(){
	int i=1;
	do{
		i=i+1;
	}while(i<10);
}
