void main(){

	int a=1;
	int b=2;
	int c;
	
	c=~b;
	c= a&b;
	c= a|b;
	c= a^b;
	c= a>>b;
	c= a>>>b;
	c= a<<b;
	
	
	c=~1;
	c= 1&b;
	c= 1|b;
	c= 1^b;
	c= 1>>b;
	c= 1>>>b;
	c= 1<<b;
	
	
	c=~1;
	c= 1&1;
	c= 1|1;
	c= 1^1;
	c= 1>>1;
	c= 1>>>1;
	c= 1<<1;
	
}
