void main(){
	bool a=false;
	bool b=true;
	int c=1;
	int d=2;
	
	a=true || false;
	a=true && false;
	a=false==false;
	a=false!=true; 
	
	a=true || a;
	a=true && a;
	a=false==a;
	a=false!=a;
	
	a=b || a;
	a=b && a;
	a=b==a;
	a=b!=a; 
	
	
	
	a=c<d;
	a=c<=d;
	a=c>d;
	a=c>=d;
	
	a=1<d;
	a=1<=d;
	a=1>d;
	a=1>=d;
	
	a=1<2;
	a=1<=2;
	a=1>2;
	a=1>=2;
	
		
}
