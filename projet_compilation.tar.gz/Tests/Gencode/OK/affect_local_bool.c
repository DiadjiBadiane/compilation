int start = 0;
int end = 100;

void main(){
    int a = 4;
    int b = 10;
    bool c;
    c = a == b;
}