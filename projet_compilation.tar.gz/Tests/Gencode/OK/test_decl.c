int start = 0;
int sum = 100;
void main(){
    int a = 5;
    int b = start;
    b = a;
}