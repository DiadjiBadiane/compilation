int start = 0;
int sum = 100;
int end = 50;
void main(){
    int a = 5;
    int b =a + 4 % (5 - (6 + 7)); 
    bool d = false || (true || false);
    int c = a << (start >> (end ^5));
}