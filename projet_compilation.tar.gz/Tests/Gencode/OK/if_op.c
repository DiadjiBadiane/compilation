int start = 0;
int sum = 100;
int end = 50;
void main(){
    int a = 5 + 6 + 7 % 8; 
    int s = (start >>> (a - end) * 4);
    a = (a ^ (end * 4));
    if(a < 4){
        int b;
    }
}