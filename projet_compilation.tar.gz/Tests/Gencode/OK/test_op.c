int start = 0;
int sum = 100;
void main(){
    int a = 5;
    int b =a + 4 % (5 - (6 + 7)); 
}