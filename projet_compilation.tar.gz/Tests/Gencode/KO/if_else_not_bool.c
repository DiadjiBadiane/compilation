int start = 0;
int end = 100;

void main(){
    int a = 10;
    
  if(a = 100){
        int b = 10;
        a = a + b;
    }
    else{
        a = 4;
    }
}
