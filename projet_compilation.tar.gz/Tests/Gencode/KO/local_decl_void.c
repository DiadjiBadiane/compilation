

void main(){
    
    
    
    void a = 10;
}
