
void main(){
    int a = 4;
    bool b = false;
    int d ;
    
    b = d;
}
