int a=0;





int b=true;

void main(){
	

}
