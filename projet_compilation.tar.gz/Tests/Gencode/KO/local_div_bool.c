void main(){
	int d = 4;
    bool a = false;
    
    
    
    int r = d / a;
}
