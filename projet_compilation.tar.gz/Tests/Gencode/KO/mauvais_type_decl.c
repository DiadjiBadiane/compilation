
void main(){
    int a = 4;
    int b = 6;
    
    
    bool d = a;
}
