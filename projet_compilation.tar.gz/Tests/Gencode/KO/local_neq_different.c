void main(){
	bool a;
    int r = 10;
    int d = 0 + r;
    
    
    a = r != a;
}
