
void main(){
    int a = 4;
    int b = 6;
    do {
        a= b ;
    }while(a + 10);
}
