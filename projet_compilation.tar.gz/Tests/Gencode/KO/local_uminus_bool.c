void main(){
	int a=1;
	bool b= false;
    
    
    
    int c = -b;
}
