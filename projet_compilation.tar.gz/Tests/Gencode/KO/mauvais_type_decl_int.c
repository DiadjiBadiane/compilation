
void main(){
    int a = 4;
    int b = 6;
    
    
    int d = false;
}
