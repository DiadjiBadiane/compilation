int start = 0;
int end = 100;




void mains(){

}
