int start = 0;
int end = 100;

void main(){
    int a = 10;
    
    while(a + start = 10){
        int b = 10;
        a = a + b;
    }
}
