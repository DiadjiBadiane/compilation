int start = 0;
int end = 100;

void main(){
    int a = 10;
    
    for(a = 10; start = 4 ;a= a + 1){
        int b = 10;
        a = a + b;
    }
}
