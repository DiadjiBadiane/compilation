void main(){
	bool a;
    int r = 10;
    
    
    
    int d = a | r;
}
