





void start = 0;
int end = 100;

void main(){

}
