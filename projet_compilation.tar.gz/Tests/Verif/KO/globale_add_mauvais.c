int a=0;
bool b=true;
void main(){



	a=a+b;

}
