void main(){
	int a=0;
	
	
	
	
	a=true*1;
}
