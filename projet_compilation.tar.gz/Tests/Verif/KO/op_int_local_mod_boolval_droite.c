void main(){
	int a=0;
	
	
	
	
	a=1%true;
}
