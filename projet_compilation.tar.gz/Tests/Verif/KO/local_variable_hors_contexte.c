void main(){
	int a=1;
	if(a==1){
		int b=0;
	}
	
	b=1;
}
