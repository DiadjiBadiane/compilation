void main(){
	int a=0;
	bool b= true;



	b = b == 1;
}
