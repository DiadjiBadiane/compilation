void main(){
	int i=1;
	while(i<10){
		int b=0;
	}
	
	b=0;
}
