void main(){

	
	
	
	
	bool a=1+1;
}
