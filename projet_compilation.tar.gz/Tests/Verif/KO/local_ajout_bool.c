void main(){

	
	
	
	
	bool a=true+true;
}
