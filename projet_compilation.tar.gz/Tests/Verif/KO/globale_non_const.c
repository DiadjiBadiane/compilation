int a=0;





int b=a;

void main(){
	

}
