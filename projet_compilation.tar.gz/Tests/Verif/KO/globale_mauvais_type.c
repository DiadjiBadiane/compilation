





int b=true;
int a=true;

void main(){
	

}
