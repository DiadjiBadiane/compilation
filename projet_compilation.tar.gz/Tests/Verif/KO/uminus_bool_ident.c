
void main(){
	bool a =true;
	
	
	
	a= -a;

}
