void main(){
	int i=1;
	do{
		int b=0;
	}while(i<10);
	
	b=0;
}
