int a=0;





bool b=0;

void main(){
	

}
