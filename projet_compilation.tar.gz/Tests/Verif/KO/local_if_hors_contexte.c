void main(){
	int i=1;
	for(i=0;i<10;i=i+1){
		int b=0;
	}
	
	b=0;
}
