void main(){
	bool a=true;
	
	
	
	
	a=true+1;
}
