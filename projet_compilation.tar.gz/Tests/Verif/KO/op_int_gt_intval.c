void main(){
	int a=0;
	bool b= true;



	a = b > 1;
}
