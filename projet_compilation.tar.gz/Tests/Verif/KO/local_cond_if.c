void main(){
	int a=1;
	
	
	
	
	if(a){
		a=a+1;
	}
}
