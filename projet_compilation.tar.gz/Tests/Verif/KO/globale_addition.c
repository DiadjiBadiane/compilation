int a=0;





int b=1+1;

void main(){
	

}
