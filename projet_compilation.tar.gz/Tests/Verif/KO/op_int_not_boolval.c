void main(){
	int  a=0;
	bool b=true;


	
	a=!true;
}
