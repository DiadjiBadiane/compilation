void main(){
	bool b=true;
	int a=0;
	
	
	
	a=b/a;
}
