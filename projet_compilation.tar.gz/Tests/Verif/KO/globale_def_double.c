int a=0;





int a;
void main(){
	

}
