void main(){
	bool a=true;
	
	
	
	
	a=1+true;
}
