void main(){
	int b=0;
	bool a=true;
	
	
	
	a=b+a;
}
