void main(){
	int a=1;
	if(a<2){
		a=0;
	}
	else{
		a=2;
	}
	print(a);
}
