void main(){

	int a=1;
	int b=1;
	
	a=a+b;
	print("attendue : 2, ", a);
	a=a*b;
	print("attendue : 2, ", a);
	a=a/b;
	print("attendue : 2, ", a);
	a=a%b;
	print("attendue : 2, ", a);
	a=a-b;
	print("attendue : 1, ", a);
	a=-a;
	print("attendue : -1, ", a);
	
	a=a+1;
	print("attendue : 0", a);
	a=a*1;
	print("attendue : 1", a);
	a=a/1;
	print("attendue : 1", a);
	a=a%1;
	print("attendue : 1", a);
	a=a-1;
	print("attendue : 0", a);
	
	a=1+a;
	print("attendue : 1", a);
	a=1*a;
	print("attendue : 1", a);
	a=1/a;
	print("attendue : 1", a);
	a=1%a;
	print("attendue : 1", a);
	a=1-a;
	print("attendue : 0", a);
	
	a=1+1;
	print("attendue : 2, ", a);
	a=2*2;
	print("attendue : 4, ", a);
	a=1/1;
	print("attendue : 1, ", a);
	a=1%1;
	print("attendue : 1, ", a);
	a=-1;
	print("attendue : -1, ", a);
	
	}
