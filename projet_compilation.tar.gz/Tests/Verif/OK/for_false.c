void main(){
	int i=1;
	int n=1;
	for(i=0;false;i=i+1){
		n=i;	
	}
	print("attendue 11, ", i);
	print("attendue 10, ", n);
}
