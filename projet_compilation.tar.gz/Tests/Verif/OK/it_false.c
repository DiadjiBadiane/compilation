void main(){
	int a=1;
	if(false){
		a=0;
	}
	else{
		a=2;
	}
	print(a);
}
