int start = 0;
int end = 100;




void main(){
    int a = 4;
    int b = a;
}
