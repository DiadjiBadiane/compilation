int a = 4;
void main(){
    if(true){
        a=a;
    }
    else{
        a=a-1;
    }
}
