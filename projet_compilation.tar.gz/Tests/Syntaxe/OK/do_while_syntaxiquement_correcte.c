void main(){
    int star = 4;
    int a=0;
    do{
    	int a=0;
    }
    while(a > 4);
}
