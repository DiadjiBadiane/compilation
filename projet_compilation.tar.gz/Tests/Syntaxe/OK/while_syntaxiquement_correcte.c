int a = 4;
void main(){
    while(false){
        a=a;
    }

}
