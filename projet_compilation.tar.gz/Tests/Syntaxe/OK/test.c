void main(){
    int star = 4;
    int a=0;
    do{
    
    }while(a > 4);
}
