void main(){
int i=0;
    for(i; i<10; i=i+1);
}
