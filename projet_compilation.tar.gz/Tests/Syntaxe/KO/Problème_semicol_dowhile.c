int main(){
    for (a; b; c); 
    
    
    
    do ; while (a = b) //Manque ; à la fin de la ligne 
}
