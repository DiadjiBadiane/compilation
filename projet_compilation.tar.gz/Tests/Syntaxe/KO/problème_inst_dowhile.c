int main(){
    for (a; b; c); 
    
    
    
    do while (a = b); //Manque inst entre do et while 
}
