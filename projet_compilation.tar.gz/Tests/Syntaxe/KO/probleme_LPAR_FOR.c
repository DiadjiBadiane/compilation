int main(){
    
    
    
    
    
    for a; b; c); //Manque parenthese apres for
}
