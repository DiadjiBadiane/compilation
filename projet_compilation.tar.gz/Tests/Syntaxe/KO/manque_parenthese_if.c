int main(){
    int a = 0; 
    int b = a;
    c = a%b;
    a + b;
    
    if a == 4){ //Manque parenthès après if
        a = 2;
    }
    else{
        a = 1;
    }
}
