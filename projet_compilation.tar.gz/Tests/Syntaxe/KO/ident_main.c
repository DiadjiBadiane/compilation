//Cas où le token après l' indication du type n' est pas un tok_ident





a main(){}
