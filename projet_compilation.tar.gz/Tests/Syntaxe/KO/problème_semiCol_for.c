int main(){
    
    
    
    
    
    for(a; b c); //Manque semicol entre b et c
}
