int a=0, b=1;





