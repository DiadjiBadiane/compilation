void main(){





int a=-;
}
