void main(){




int a
}
