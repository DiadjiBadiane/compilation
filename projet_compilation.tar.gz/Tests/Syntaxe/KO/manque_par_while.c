int start = 0;
int end = 100;
void main(){
	int i, s = start, e = end;
	int sum = 0;
	print("sum : ", sum, "\n");
   	 while a * b)

}
