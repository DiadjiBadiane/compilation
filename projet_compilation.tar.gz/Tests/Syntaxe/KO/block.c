void main(){





while(true;)
}
