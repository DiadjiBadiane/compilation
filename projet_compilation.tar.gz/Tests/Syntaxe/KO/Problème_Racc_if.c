int main(){
    int a = 0; 
    int b = a;
    if (a == 4){
        a = 2;
    //Manque accolade
    else{
        a = 1;
    }
}
