void main(){





int a=~;
}
