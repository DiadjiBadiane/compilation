





int main(){
int a = 0;
}
