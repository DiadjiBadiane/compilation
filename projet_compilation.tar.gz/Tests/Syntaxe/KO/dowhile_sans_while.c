void main(){




do;
}
