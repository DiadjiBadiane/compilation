void main(){



	int b=0;
	int a=0;
	int a b;
}
