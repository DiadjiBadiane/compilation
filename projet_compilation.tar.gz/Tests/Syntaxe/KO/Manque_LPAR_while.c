int start = 0;
int end = 100;
void main(){
	int i, s = start, e = end;
	
	print("sum : ", sum, "\n");
    	while a * b)//Manque parenthèse

}
