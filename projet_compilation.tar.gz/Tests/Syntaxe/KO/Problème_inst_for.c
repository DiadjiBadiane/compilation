int main(){
    
    
    
      
    for (a; b; c) //Manque inst apres for
}
