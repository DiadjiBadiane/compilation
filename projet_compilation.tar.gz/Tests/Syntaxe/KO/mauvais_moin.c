void main(){





int a=1-;
}
