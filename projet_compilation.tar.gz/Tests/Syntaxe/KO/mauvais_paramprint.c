void main(){





print("voila", ;, "bonjour");
}
