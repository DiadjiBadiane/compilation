void main(){





int a=a!=;
}
