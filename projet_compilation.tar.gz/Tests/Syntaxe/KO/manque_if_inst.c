int main(){
    int a = 0; 
    int b = a;
    c = a%b;
    a + b;
    
    (a == 4){
        a = 2;
    }
    else{
        a = 1;
    }
}
